import pandas as pd
import numpy as np
import pickle
import nltk
from nltk.corpus import stopwords
import re
from bs4 import BeautifulSoup

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import jaccard_score, make_scorer

# download stop words
nltk.download('stopwords')

# import my stop words
my_stopwords = pd.read_csv("./scripts/my_stopwords.csv").values.squeeze().tolist()

# import my stop words
my_labels = pd.read_csv("./scripts/my_labels.csv").values.squeeze().tolist()

# fonction de scoring pour modeliser
def jaccard(y_true, y_score):
    probs = np.transpose([prob[:, 1] for prob in y_score])
    size=100
    average_jaccard = np.zeros(size)
    jaccard = []
    threshold = []
    for i in np.linspace(0, 1.0, num=size):
        y_pred_class = np.array(probs) > i
        jaccard.append(jaccard_score(y_pred_class,y_true,average='macro'))
        threshold.append(i)
    return jaccard[np.argmax(jaccard)]

# fonction de nettoyage
def nettoyer(text):
    text = BeautifulSoup(text,features="html.parser").get_text()
    text = re.sub("[^a-zA-Z]", " ", text)
    text = text.lower()
    words = text.split()
    set_stopwords = set(stopwords.words("english")+my_stopwords)
    meaningful_words = [w for w in words if not w in set_stopwords]   
    return( " ".join(meaningful_words))

# fonction vectoriser tfidf
def vectoriser(text):
    filename = "./scripts/multi_tfidf_vectorizer.sav"
    multi_tfidf_vectorizer = pickle.load(open(filename, 'rb'))
    return multi_tfidf_vectorizer.transform([text])

# fonction modeliser
def modeliser(x):
    filename = "./scripts/logistic_regression.sav"
    logistic_regression = pickle.load(open(filename, 'rb'))
    y = logistic_regression.predict(x)
    print(y)
    return y

# retourne les étiquettes pour les predictions
def labels(y, labels):
    pred = []
    for i, is_label in enumerate(y[0]):
        if is_label == 0:
            pass
        else :
            pred.append(labels[i])
    return pred


def predire(text):
    a = nettoyer(text)
    b = vectoriser(a)
    c = modeliser(b)
    predicted_tags = labels(c, labels=my_labels)
    return predicted_tags

